# 42TESTERS-GNL

This is a complete tester for the 2019 version of the 42 project GetNextLine.
However it does not test leaks in as much detail as the moulinette. /!\

1 - cd to the folder with your fonctions

2 - git clone https://github.com/Mazoise/42TESTERS-GNL.git 

3 - cd 42TESTERS-GNL

4 - bash all_tests.sh or all_tests_with_bonus.sh
