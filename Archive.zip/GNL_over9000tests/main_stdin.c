#include "gnl_cpy/get_next_line.h"
#include <stdio.h>

int main()
{
	char *line;
	 get_next_line(0,&line);
		printf("%s\n",line);
	

}
