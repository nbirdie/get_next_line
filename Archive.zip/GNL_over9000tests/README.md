# GET NEXT LINE TESTER
1 - EDIT Makefile PATH\
2 - bash run.sh
